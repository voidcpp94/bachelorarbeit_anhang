# TS-UNB 

Welcome to TS-UNB-Lib. It implements the standard ETSI TS 103 357 TS-UNB.  
This library mainly focuses on educational and personal use. Furthremore, it currently only implements the uplink.  
For professional use commercial libraries are available. See the license for more details.


## Supported Devices

This library supports the devices listet below. The list of devices will be extended in the future.
### Systems
* Arduino systems with ATmega328p processor (8MHz and 16MHz) (containted in src folder)
* Raspberry Pi Pico (contained in RPPico folder)

### Transceiver Chipsets
* HopeRF RFM69hw


## License
See the file [LICENSE.md](LICENSE.md) for details on the software license for this library.